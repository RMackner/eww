# simplexpr

simplexpr is a parser and interpreter for a simple expression syntax that can be embedded into other applications or crates.
It is being developed to be used in [eww](https://github.com/elkowar/eww), but may also other uses.

For now, this is highly experimental, unstable, and ugly. You most definitely do not want to use this crate.
