use derive_more::*;
use serde::{Deserialize, Serialize};

pub mod coords;
pub use coords::*;
