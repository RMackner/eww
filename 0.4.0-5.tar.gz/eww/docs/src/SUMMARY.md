# Summary

- [Eww - Widgets for everyone!](./eww.md)
- [Configuration](./configuration.md)
- [Eww expressions](./expression_language.md)
- [Theming with GTK](./working_with_gtk.md)
- [Magic Variables](./magic-vars.md)
- [Widgets](./widgets.md)
- [Troubleshooting](./troubleshooting.md)
- [Examples](./examples.md)
