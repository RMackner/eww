## Example Configurations

These configurations of eww are available in the `examples/` directory of the [repo](https://github.com/elkowar/eww).

An eww bar configuration:
![Example bar](https://github.com/elkowar/eww/raw/master/examples/eww-bar/eww-bar.png)
