# Magic variables

These are variables that are always there, without you having to import them.

The delay between the updating variables is always 2s.

